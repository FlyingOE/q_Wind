#ifndef __K_PTR_H__
#define __K_PTR_H__
#pragma comment(lib, "kdb+.util.lib")

#include "util.h"

#include <memory>	//C++11: std::unique_ptr<>

namespace q {

	struct K_delete {
		void operator()(K k) const {
			if (k != K_NIL) r0(k);
		}
	};

	typedef std::unique_ptr<k0, K_delete> K_ptr;

}//namespace q

#endif//__K_PTR_H__