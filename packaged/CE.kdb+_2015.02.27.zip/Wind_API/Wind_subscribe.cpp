#include "stdafx.h"
#include "Wind_API.h"

#include "util.h"
#include "WindEvent.h"

#include "kdb+.util/K_ptr.h"
#include "kdb+.util/type_convert.h"
#include <iostream>

namespace Wind {
	namespace pubsub {

		template <typename Char, typename Traits>
		bool processResult(Event const& event, char const* callback, std::basic_ostream<Char, Traits>& errorLog) {
			q::K_ptr data;
			try {
				data.reset(event.parse());
			}
			catch (std::string const& ex) {
				errorLog << "<WQ> response format error: " << ex;
				return false;
			}

			std::string error;
			if (event.ErrCode != WQERR_OK) {
				error = util::error2Text(event.ErrCode);
			}

			static_assert(sizeof(::WQID) <= sizeof(J), "WQID data type mismatch");
			q::K_ptr result(k(0,
				const_cast<S>(callback),
				kj(event.RequestID), kp(const_cast<S>(error.c_str())), data.release(), K_NIL));
			if (result.get() == K_NIL) {
				errorLog << "<q> 'network error" << std::endl;
				return false;
			}
			else if (result->t == -128) {
				errorLog << "<q> '" << result->s << std::endl;
				return false;
			}
			else {
				return true;
			}
		}

		int WINAPI subscribe(::WQEvent* pEvent, LPVOID lpUserParam) {
			char const* callback = static_cast<char const*>(lpUserParam);
			assert(callback != NULL);

			assert(pEvent != NULL);
			switch (pEvent->EventType) {
			case eWQPartialResponse:
				return processResult(static_cast<Event&>(*pEvent), callback, std::cerr);
			case eWQErrorReport:
				std::cerr << "<WQ> error report: " << util::error2Text(pEvent->ErrCode) << std::endl;
				return false;
			case eWQOthers:
				if (pEvent->ErrCode == WQERR_USER_CANCEL) {
					delete[] callback;	// Make sure memory is reclaimed!
					callback = NULL;
					return true;
				}
				// fall through
			default:
				std::cerr << "<WQ> unsupported subscription response: " << *pEvent << std::endl;
				return false;
			}
		}

	}//namespace Wind::pubsub
}//namespace Wind

WIND_API K K_DECL Wind_wsq(K windCodes, K indicators, K params, K callback) {
	std::wstring codes, indis, paras;
	std::unique_ptr<char[]> func;
	try {
		codes = Wind::util::qList2WStringJoin(windCodes, L',');
		indis = Wind::util::qList2WStringJoin(indicators, L',');
		paras = Wind::util::qDict2WStringMapJoin(params, L';', L'=');
		std::string const funcName = q::q2String(callback);
		func.reset(new char[funcName.size() + 1]);
		std::memset(func.get(), '\0', funcName.size() + 1);
#		ifdef _MSC_VER
		std::copy(funcName.begin(), funcName.end(), stdext::make_unchecked_array_iterator(func.get()));
#		else
		std::copy(funcName.begin(), funcName.end(), func.get());
#		endif
		assert(std::strlen(func.get()) == funcName.size());
	}
	catch (std::string const& error) {
		return q::error2q(error);
	}

	::WQID const qid = ::WSQ(codes.c_str(), indis.c_str(), paras.c_str(),
		&Wind::pubsub::subscribe, func.release());
	if (qid == 0) {
		return q::error2q("subscription failed");
	}
	else if (qid < 0) {
		return q::error2q(Wind::util::error2Text(static_cast<::WQErr>(qid)));
	}

	static_assert(sizeof(::WQID) == sizeof(J), "WQID data type mismatch");
	return kj(qid);
}

WIND_API K K_DECL Wind_cr(K qid) {
	::WQID id = -1;
	static_assert(sizeof(::WQID) >= sizeof(J), "WQID data type mismatch");
	try {
		id = q::q2Dec(qid);
	}
	catch (std::string const& error) {
		return q::error2q(error);
	}

	::WQErr const error = ::CancelRequest(id);
	if (error != WQERR_OK) {
		return q::error2q(Wind::util::error2Text(error));
	}
	else {
		return K_NIL;
	}
}

WIND_API K K_DECL Wind_car(K _) {
	::WQErr const error = ::CancelAllRequest();
	if (error != WQERR_OK) {
		return q::error2q(Wind::util::error2Text(error));
	}
	else {
		return K_NIL;
	}
}